import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import AuthGuard from "./components/AuthGuard";
import AppShell from "./components/AppShell";
import HomePage from "./components/HomePage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import AuthActionPage from "./pages/AuthActionPage";
import WaitlistPage from "./pages/WaitlistPage";
import AboutPage from "./pages/AboutPage";
import TermsPage from "./pages/legal/TermsPage";
import PrivacyPage from "./pages/legal/PrivacyPage";
import AIPolicyPage from "./pages/legal/AIPolicyPage";
import AdminPage from "./pages/AdminPage";
import ProfilePage from "./pages/ProfilePage";
import AnnouncementsPage from "./pages/AnnouncementsPage";
import MessagingPage from "./tools/messaging/MessagingPage";
import RebuttalPage from "./tools/rebuttal/RebuttalPage";
import RapidResponsePage from "./tools/rapid-response/RapidResponsePage";
import ResourcesPage from "./tools/resources/ResourcesPage";
import LibraryPage from "./tools/library/LibraryPage";
import MediaPage from "./tools/media/MediaPage";
import QuickStartPage from "./tools/quick-start/QuickStartPage";
import ManualPage from "./tools/manual/ManualPage";
import MisinfoMonitorPage from "./tools/misinfo-monitor/MisinfoMonitorPage";
import StormsHubPage from "./tools/storms/StormsHubPage";
import PublicStormPage from "./pages/PublicStormPage";
import PublicStormsListPage from "./pages/PublicStormsListPage";
import VoterLookupPage from "./pages/VoterLookupPage";
import CountyPagesPage from "./pages/CountyPagesPage";
import CountySlateCardPage from "./pages/CountySlateCardPage";
import PromptSandboxPage from "./tools/sandbox/PromptSandboxPage";

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          {/* Public routes */}
          <Route path="/login"    element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          {/* Owned replacement for Firebase's default hosted auth-action
              page (Aug 2026, TODO #1) — handles password reset, email
              verification, and email-change-revert links. This route only
              actually gets hit once Firebase Console's "Customize action
              URL" is set for the Password reset and Email address
              verification templates (Authentication → Templates → pencil
              icon) to point here — see AuthActionPage.jsx's header comment. */}
          <Route path="/auth-action" element={<AuthActionPage />} />
          <Route path="/waitlist" element={<WaitlistPage />} />
          {/* Public "who we are" page — Aug 2026. /welcome is just an
              alias to the same component so either link works; /about is
              the canonical path used in the footer and elsewhere. */}
          <Route path="/about"    element={<AboutPage />} />
          <Route path="/welcome"  element={<AboutPage />} />
          {/* Legal pages — Aug 2026. TermsPage/PrivacyPage/AIPolicyPage
              already existed as standalone components (self-contained via
              LegalPageLayout, no AppShell dependency) but were never
              actually routed anywhere — RegisterPage.jsx and
              WaitlistPage.jsx have linked to /terms, /privacy, /ai-policy
              (target="_blank") all along, but every click 404'd since
              nothing in this file registered those paths. Public routes,
              same as /waitlist above, since people see these before
              they're ever logged in. */}
          <Route path="/terms"     element={<TermsPage />} />
          <Route path="/privacy"   element={<PrivacyPage />} />
          <Route path="/ai-policy" element={<AIPolicyPage />} />
          <Route path="/storm/:token" element={<PublicStormPage />} />
          <Route path="/storms/public" element={<PublicStormsListPage />} />
          <Route path="/voter-lookup" element={<VoterLookupPage />} />
          {/* Sept 29 2026 — public directory of the 15 county Democratic
              Party websites (replaces the standalone Canva page). Linked
              from the Resources Hub's Election Resources group. */}
          <Route path="/county-pages" element={<CountyPagesPage />} />
          {/* Sept 29 2026 — one county's slate card, phone-friendly, with
              a shareable link + QR. Only counties listed in
              src/data/countyMaterials.js have one; others show a friendly
              "no slate card here yet" page. */}
          <Route path="/county-pages/:slug" element={<CountySlateCardPage />} />

          {/* Protected routes */}
          <Route element={
            <AuthGuard>
              <AppShell />
            </AuthGuard>
          }>
            <Route path="/"                element={<HomePage />} />
            {/* /research renders nothing here — AppShell keeps a
                persistent <ResearchPage /> mounted itself (see its header
                comment) so navigating away and back doesn't reset it. This
                route stays registered so the auth guard, layout, direct
                links, and back/forward navigation still work correctly. */}
            <Route path="/research"        element={null} />
            <Route path="/messaging"       element={<MessagingPage />} />
            <Route path="/rebuttal"        element={<RebuttalPage />} />
            <Route path="/rapid-response"  element={<RapidResponsePage />} />
            <Route path="/resources"       element={<ResourcesPage />} />
            <Route path="/library"         element={<LibraryPage />} />
            <Route path="/media"           element={<MediaPage />} />
            <Route path="/admin"           element={<AdminPage />} />
            <Route path="/profile"         element={<ProfilePage />} />
            <Route path="/announcements"   element={<AnnouncementsPage />} />
            <Route path="/quick-start"     element={<QuickStartPage />} />
            <Route path="/manual"          element={<ManualPage />} />
            <Route path="/misinfo-monitor" element={<MisinfoMonitorPage />} />
            <Route path="/storms"          element={<StormsHubPage />} />
            <Route path="/sandbox"         element={<PromptSandboxPage />} />
          </Route>
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
